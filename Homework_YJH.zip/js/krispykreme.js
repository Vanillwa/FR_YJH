$('#show-hours').on('click', function(){
    let scrollHeight =  $('#hours-detail').prop('scrollHeight') + 'px';

    // $(this).toggleClass('show');
    $(this).text(($(this).text() == 'SHOW HOURS ▼' ? 'HIDE HOURS ▲' : 'SHOW HOURS ▼'));

    if($('#hours-detail').css('max-height') == '0px')
        $('#hours-detail').css('max-height', scrollHeight);
    else
        $('#hours-detail').css('max-height', '0px');
});