module.exports = {
    host : 'localhost',
    user : 'root',
    password : '1111',
    database : 'test',
    dateStrings: 'date'
}